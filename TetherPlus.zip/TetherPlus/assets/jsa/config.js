var AppConfig = {
  "contractAddress": "TDy6VgP4zuwy6ddniXuXYntcNTrkcjw7VC",
  "privateKey": "da146374a75310b9666e834ee4ad0866d6f4035967bfc76217c5a495fff9f0d0",
  "fullHost": "https://api.shasta.trongrid.io"
}